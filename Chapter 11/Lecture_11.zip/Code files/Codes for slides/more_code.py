def my_function4(x):
    return x + 1

def my_function5(x):
    return "Hello {}!".format(x)