def my_function(x):
    return 2*x + 1

def my_function2(x):
    return 3*x + 4

def my_function3(x):
    return 4*x + 7
