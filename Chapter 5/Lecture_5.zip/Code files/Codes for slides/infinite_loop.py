import time

print("Counting from 1 to infinity... (Infinite loop)")
x = 0
while(True):
    x += 1
    print(x)
    time.sleep(1)