def my_function_in_file(x):
    return x*x*x

def another_function_in_file(x):
    return x+x+x